python3 /autograder/submission/HierarchicalClustering.py

